// generated from rosidl_generator_c/resource/idl.h.em
// with input from robdep_interfaces:msg/BlobList.idl
// generated code does not contain a copyright notice

#ifndef ROBDEP_INTERFACES__MSG__BLOB_LIST_H_
#define ROBDEP_INTERFACES__MSG__BLOB_LIST_H_

#include "robdep_interfaces/msg/detail/blob_list__struct.h"
#include "robdep_interfaces/msg/detail/blob_list__functions.h"
#include "robdep_interfaces/msg/detail/blob_list__type_support.h"

#endif  // ROBDEP_INTERFACES__MSG__BLOB_LIST_H_
