// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBDEP_INTERFACES__MSG__BLOB_LIST_HPP_
#define ROBDEP_INTERFACES__MSG__BLOB_LIST_HPP_

#include "robdep_interfaces/msg/detail/blob_list__struct.hpp"
#include "robdep_interfaces/msg/detail/blob_list__builder.hpp"
#include "robdep_interfaces/msg/detail/blob_list__traits.hpp"

#endif  // ROBDEP_INTERFACES__MSG__BLOB_LIST_HPP_
