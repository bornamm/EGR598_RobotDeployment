// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBDEP_INTERFACES__MSG__BLOB_DATA_HPP_
#define ROBDEP_INTERFACES__MSG__BLOB_DATA_HPP_

#include "robdep_interfaces/msg/detail/blob_data__struct.hpp"
#include "robdep_interfaces/msg/detail/blob_data__builder.hpp"
#include "robdep_interfaces/msg/detail/blob_data__traits.hpp"

#endif  // ROBDEP_INTERFACES__MSG__BLOB_DATA_HPP_
