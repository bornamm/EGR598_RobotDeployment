# generated from colcon_powershell/shell/template/hook_prepend_value.ps1.em

colcon_prepend_unique_value LD_LIBRARY_PATH "$env:COLCON_CURRENT_PREFIX\lib"
