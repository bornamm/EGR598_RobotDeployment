# robdep_project > 2023-04-18 6:01pm
https://universe.roboflow.com/object-detection/robdep_project

Provided by a Roboflow user
License: CC BY 4.0

